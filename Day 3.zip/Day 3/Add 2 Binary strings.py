a =input("a=")
b =input("b=")
sum = bin(int(a, 2) + int(b, 2)) 
print(sum[2:])
