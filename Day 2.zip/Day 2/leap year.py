y=int(input("Enter the year"))
if(y%4==0):
    print("Given year is a leap year")
else:
    print("Given year is not a leap year")
